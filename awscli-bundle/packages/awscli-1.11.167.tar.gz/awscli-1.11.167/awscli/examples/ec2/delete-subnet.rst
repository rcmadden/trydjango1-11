**To delete a subnet**

This example deletes the specified subnet. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-subnet --subnet-id subnet-9d4a7b6c
